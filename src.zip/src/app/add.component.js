"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var movie_service_1 = require("./movie.service");
var AddComponent = (function () {
    /**
    * Initialise automatically
    * @param movies
    */
    function AddComponent(movieService) {
        this.data = movieService.getMovies();
    }
    /**
  * Get movie function
  */
    AddComponent.prototype.getMovies = function () {
        //this.data = movieService.getMovies();
    };
    /**
   * Injecting movie data from MovieService
   */
    AddComponent.prototype.ngOnInit = function () {
        this.getMovies;
    };
    /**
     * Add movie function
     */
    AddComponent.prototype.add = function () {
        this.message = "";
        typeof this.newName;
        typeof this.newDirector;
        if (typeof this.newName == "undefined") {
            this.message = "Movie name is required.";
        }
        else if (typeof this.newDirector == "undefined") {
            this.message = "Director is required.";
        }
        else if (typeof this.newYear == "undefined") {
            this.message = "Year is required.";
        }
        else if (typeof this.newGenre == "undefined") {
            this.message = "Genre is required.";
        }
        else {
            var m = void 0;
            m = {
                name: this.newName,
                director: this.newDirector,
                year: this.newYear,
                genre: this.newGenre,
                notes: this.newNotes,
            };
            //this.movieService.doAdd(m);
            //this.getMovies();
            this.message = this.newName + " has been saved.";
        }
    };
    return AddComponent;
}());
AddComponent = __decorate([
    core_1.Component({
        template: "\n    <h2>Add Movie</h2>\n    <h4>Please fill all fields</h4>\n    \n<form>\n  <label for=\"newName\">Movie name:</label>\n  <input type=\"text\" id=\"newName\" required [(ngModel)]=newName name=\"newName\" />\n  <br>\n  <br>\n  <label for=\"newDirector\">Director:</label>\n  <input type=\"text\" id=\"newDirector\" required [(ngModel)]=newDirector name=\"newDirector\" />\n  <br>\n  <br>\n  <label for=\"newYear\">Year:</label>\n    <input type=\"text\" id=\"newYear\" required [(ngModel)]=newYear name=\"newYear\" />\n  <br>\n  <br>\n  <label for=\"newGenre\">Genre:</label>\n     <input id=\"newGenre\" name=\"newGenre\"list=\"genre\"  [(ngModel)]=newGenre class=\"drop\"required=\"Type is required\" > \n      <datalist id= \"genre\">\n        <option value=\"comedy\">comedy</option>\n        <option value=\"horror\">horror</option>\n        <option value=\"action\">action</option>\n        <option value=\"romantic\">romantic</option>\n        <option value=\"thriller\">thriller</option>\n        <option value=\"drama\">drama</option>\n      </datalist>\n    \n    <br>\n  <br>\n  <label for=\"newYear\">Notes:</label>\n  <input type=\"text\" [(ngModel)]=\"newNotes\" name=\"newYear\" id=\"newYear\">\n  <br>\n  <br>\n  <button type=\"button\" (click)=\"add()\">Add Movie</button>\n  <input type=\"reset\" value=\"Reset form\" />\n  <p>{{message}}</p>\n    </form>\n"
    }),
    __metadata("design:paramtypes", [movie_service_1.MovieService])
], AddComponent);
exports.AddComponent = AddComponent;
//# sourceMappingURL=add.component.js.map