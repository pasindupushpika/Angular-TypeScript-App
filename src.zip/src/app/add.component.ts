/**@author Pasindu Pushpika Sudasinghe Appuhamilage.
    Southern Cross University Melbourne.
    Version 4.2.0
**/
import { Component, OnInit } from '@angular/core';
import { MovieService, Movie } from './movie.service';

@Component({
    template:`
    <h2>Add Movie</h2>
    <h4>Please fill all fields</h4>
    
<form>
  <label for="newName">Movie name:</label>
  <input type="text" id="newName" required [(ngModel)]=newName name="newName" />
  <br>
  <br>
  <label for="newDirector">Director:</label>
  <input type="text" id="newDirector" required [(ngModel)]=newDirector name="newDirector" />
  <br>
  <br>
  <label for="newYear">Year:</label>
    <input type="text" id="newYear" required [(ngModel)]=newYear name="newYear" />
  <br>
  <br>
  <label for="newGenre">Genre:</label>
     <input id="newGenre" name="newGenre"list="genre"  [(ngModel)]=newGenre class="drop"required="Type is required" > 
      <datalist id= "genre">
        <option value="comedy">comedy</option>
        <option value="horror">horror</option>
        <option value="action">action</option>
        <option value="romantic">romantic</option>
        <option value="thriller">thriller</option>
        <option value="drama">drama</option>
      </datalist>
    
    <br>
  <br>
  <label for="newYear">Notes:</label>
  <input type="text" [(ngModel)]="newNotes" name="newYear" id="newYear">
  <br>
  <br>
  <button type="button" (click)="add()">Add Movie</button>
  <input type="reset" value="Reset form" />
  <p>{{message}}</p>
    </form>
`
})


export class AddComponent implements OnInit {
        
        
        data: Movie[];
        
   /**
   * Initialise automatically
   * @param movies
   */

    constructor(movieService: MovieService) {
       this.data = movieService.getMovies();    
       
   }
   
      
     /**
   * Get movie function
   */ 
    getMovies(){
     //this.data = movieService.getMovies();
    
    
  }
  
  
   /**
  * Injecting movie data from MovieService
  */ 
  
  ngOnInit(): void {
    this.getMovies;
  }
  /**
    *defining the types of the HTML form ID's, Label 
  */
  newName: string;
  newDirector: string;
  newYear: number;
  newGenre: string;
  newNotes: string;
  message:string;
 
 

  /**
   * Add movie function
   */ 
  
add() {
    this.message = "";
    typeof this.newName;
    typeof this.newDirector;
    if(typeof this.newName == "undefined"){
      this.message = "Movie name is required.";
    }
        else if(typeof this.newDirector == "undefined"){
      this.message = "Director is required.";
    }
    
        else if(typeof this.newYear == "undefined"){
      this.message = "Year is required.";
    }
           else if(typeof this.newGenre == "undefined"){
      this.message = "Genre is required.";
    }

     // else if (this.movieService.isExist(this.newName)) {
       // this.message = "There is another movie with the same movie name.";
     // }
    
    else {
      let m: Movie;
      m = { 
        name: this.newName, 
        director: this.newDirector, 
        year: this.newYear,
        genre: this.newGenre,
        notes: this.newNotes,
      };
       //this.movieService.doAdd(m);
       //this.getMovies();
       this.message = this.newName + " has been saved."
    }
  }
  
  


}