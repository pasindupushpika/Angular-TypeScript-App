"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var platform_browser_1 = require("@angular/platform-browser");
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var home_component_1 = require("./home.component");
var list_component_1 = require("./list.component");
var add_component_1 = require("./add.component");
var browse_component_1 = require("./browse.component");
var help_component_1 = require("./help.component");
var movie_service_1 = require("./movie.service");
var moviePages = [
    { path: 'Home', component: home_component_1.HomeComponent },
    { path: 'List', component: list_component_1.ListComponent },
    { path: 'Add', component: add_component_1.AddComponent },
    { path: 'Browse', component: browse_component_1.BrowseComponent },
    { path: 'Help', component: help_component_1.HelpComponent },
    { path: '', redirectTo: "/Home", pathMatch: 'full' },
    { path: '**', component: home_component_1.HomeComponent }
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        declarations: [
            app_component_1.AppComponent,
            home_component_1.HomeComponent,
            list_component_1.ListComponent,
            add_component_1.AddComponent,
            browse_component_1.BrowseComponent,
            help_component_1.HelpComponent
        ],
        imports: [
            platform_browser_1.BrowserModule,
            forms_1.FormsModule,
            router_1.RouterModule.forRoot(moviePages)
        ],
        providers: [movie_service_1.MovieService],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map