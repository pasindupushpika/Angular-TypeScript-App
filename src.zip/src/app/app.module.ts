import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { ListComponent } from './list.component';
import { AddComponent } from './add.component';
import { BrowseComponent } from './browse.component';
import { HelpComponent } from './help.component';

import { MovieService } from './movie.service';

const moviePages: Routes = [
   {path:'Home', component:HomeComponent},
   {path:'List', component:ListComponent},
   {path:'Add',  component:AddComponent},
   {path:'Browse', component:BrowseComponent},
   {path:'Help', component:HelpComponent},
   {path:'', redirectTo:"/Home", pathMatch:'full'},
   {path:'**', component: HomeComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ListComponent,
    AddComponent,
	BrowseComponent,
    HelpComponent
  ],
  imports: [
    BrowserModule,
	FormsModule,
	RouterModule.forRoot(moviePages)
  ],
  providers: [ MovieService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
