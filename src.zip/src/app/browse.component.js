"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var movie_service_1 = require("./movie.service");
var BrowseComponent = (function () {
    function BrowseComponent(movieService) {
        this.currentIndex = 1;
        this.dialogVar = false;
        this.dialogDeleteButton = true;
        this.data = movieService.getMovies();
        if (this.data.length == 0) {
            this.message = "Already at the first of data.";
        }
        else {
            this.currentIndex = 1;
            var thisMovie = this.data[0];
            this.newName = thisMovie.name;
            this.newDirector = thisMovie.director;
            this.newYear = thisMovie.year;
            this.newGenre = thisMovie.genre;
            this.newNotes = thisMovie.notes;
        }
    }
    /**
* Injecting movie data from MovieService
*/
    BrowseComponent.prototype.ngOnInit = function () {
    };
    /**
    * Loading previous data
    */
    BrowseComponent.prototype.doPrev = function () {
        if (this.currentIndex <= 1) {
            this.message = "Already at the first of data.";
        }
        else {
            this.message = "";
            this.currentIndex--;
            var prevMovie = this.data[this.currentIndex - 1];
            this.newName = prevMovie.name;
            this.newDirector = prevMovie.director;
            this.newYear = prevMovie.year;
            this.newGenre = prevMovie.genre;
            this.newNotes = prevMovie.notes;
        }
    };
    /**
    * Loading next data
    */
    BrowseComponent.prototype.doNext = function () {
        if (this.currentIndex == this.data.length) {
            this.message = "Woops~ This is the last of data.";
        }
        else {
            this.message = "";
            this.currentIndex++;
            var nextMovie = this.data[this.currentIndex - 1];
            this.newName = nextMovie.name;
            this.newDirector = nextMovie.director;
            this.newYear = nextMovie.year;
            this.newGenre = nextMovie.genre;
            this.newNotes = nextMovie.notes;
        }
    };
    /**
   * Edit data
   */
    BrowseComponent.prototype.doEdit = function () {
        if (this.currentIndex <= 0) {
            this.message = "There is no unit to update";
        }
        else if (this.data[this.currentIndex - 1].name != this.newName) {
            this.message = "Error";
        }
        else {
            this.data[this.currentIndex - 1].name = this.newName;
            this.data[this.currentIndex - 1].director = this.newDirector;
            this.data[this.currentIndex - 1].year = this.newYear;
            this.data[this.currentIndex - 1].genre = this.newGenre;
            this.data[this.currentIndex - 1].notes = this.newNotes;
            this.message = this.data[this.currentIndex - 1].name + " has been updated.";
        }
    };
    /**
   * Show the dialog for confirm a data is going to delete
   */
    BrowseComponent.prototype.showDialog = function () {
        this.dialogVar = true;
        this.dialogDeleteButton = false;
    };
    /**
    * Confirm to delete
    */
    BrowseComponent.prototype.doDeleteYes = function () {
        //delete the data by the current location in the array
        this.data.splice(this.currentIndex, 1);
        //current location is going to decrease if the index same as the length of unit array
        if (this.currentIndex == this.data.length) {
            this.currentIndex--;
        }
        //show message if there is no unit  
        if (this.data.length == 0) {
            this.message = "No movies in the list.";
            this.newName = "";
            this.newDirector = "";
        }
        else {
            this.newName = this.data[this.currentIndex].name;
            this.newDirector = this.data[this.currentIndex].director;
            this.message = this.newName + " confirmed delete.";
            this.dialogVar = false;
            this.dialogDeleteButton = true;
        }
    };
    /**
     * Cancel to delete
     */
    BrowseComponent.prototype.doDeleteNo = function () {
        this.dialogVar = false;
        this.dialogDeleteButton = true;
    };
    /**
    * Load details into corresponding input field
    * when data is selected from select list
    * @param value
    */
    BrowseComponent.prototype.movieDetails = function (value) {
        this.data.forEach(function (arrayMovie) {
            if (value == arrayMovie.name) {
                this.newName.value = arrayMovie.name;
                this.newDirector.value = arrayMovie.director;
                this.newYear.value = arrayMovie.year;
                this.newGenre.value = arrayMovie.genre;
                this.newNotes.value = this.data[this.currentIndex].notes;
            }
        });
    };
    /**
     * Changing data by selecting a unit code
     * @param event
     */
    BrowseComponent.prototype.onChange = function (event) {
        this.newName = event.target.value;
    };
    return BrowseComponent;
}());
BrowseComponent = __decorate([
    core_1.Component({
        template: "<h2>Movie Browser</h2>\n\t\t\t  <form>\n\t\t\t  <p>  </p>\n\t\t\t  <label for=\"newName\">Movie name:</label>\n\t\t\t  <input type=\"text\" id=\"newName\" required\n\t\t\t         [(ngModel)]=\"newName\" name=\"newName\"/>\n\t\t\t  <br>\n              \n                <p> </p>\n\t\t\t  <label for=\"newDirector\">Movie director:</label>\n\t\t\t  <input type=\"text\" id=\"newDirector\" required\n\t\t\t         [(ngModel)]=\"newDirector\" name=\"newDirector\"/>\n\t\t\t  <br>\n              \n               <p> </p>\n\t\t\t  <label for=\"newYear\">Movie year:</label>\n\t\t\t  <input type=\"text\" id=\"newYear\" required\n\t\t\t         [(ngModel)]=\"newYear\" name=\"newYear\"/>\n\t\t\t  <br>\n              \n              <p>  </p>\n\t\t\t  <label for=\"newGenre\">Movie genre:</label>\n\t\t\t  <input type=\"text\" id=\"newGenre\" required\n\t\t\t         [(ngModel)]=\"newGenre\" name=\"newGenre\"/>\n\t\t\t  <br>\n              \n               <p>  </p>\n\t\t\t  <label for=\"newNotes\">Movie notes:</label>\n\t\t\t  <input type=\"text\" id=\"newNotes\" required\n\t\t\t         [(ngModel)]=\"newNotes\" name=\"newNotes\"/>\n\t\t\t  <br>\n\t\t\t \n              <button type=\"button\" (click)=\"doEdit();\">Edit</button>\n              <button type=\"button\" (click)=\"doPrev()\">Previous</button>\n              <button type=\"button\" (click)=\"doNext()\">Next</button>\n              <button type=\"button\" (click)=\"showDialog();\" [hidden]=\"!dialogDeleteButton\">Delete</button>\n            </form>\n            <div id=\"deleteDialog\" #dialogBox [hidden]=\"!dialogVar\">\n              <p>Do you really want to delete?\n                <button (click)=\"doDeleteYes()\">Yes</button>/\n                <button (click)=\"doDeleteNo()\">No</button>\n              </p>\n            </div>\n            <p>{{message}}</p>\n\t\t\t "
    }),
    __metadata("design:paramtypes", [movie_service_1.MovieService])
], BrowseComponent);
exports.BrowseComponent = BrowseComponent;
//# sourceMappingURL=browse.component.js.map