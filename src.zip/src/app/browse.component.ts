/**@author Pasindu Pushpika Sudasinghe Appuhamilage.
    Southern Cross University Melbourne.
    Version 4.2.0
**/

import { Component, OnInit } from '@angular/core';
import { MovieService, Movie } from './movie.service';

@Component({
    template:`<h2>Movie Browser</h2>
			  <form>
			  <p>  </p>
			  <label for="newName">Movie name:</label>
			  <input type="text" id="newName" required
			         [(ngModel)]="newName" name="newName"/>
			  <br>
              
                <p> </p>
			  <label for="newDirector">Movie director:</label>
			  <input type="text" id="newDirector" required
			         [(ngModel)]="newDirector" name="newDirector"/>
			  <br>
              
               <p> </p>
			  <label for="newYear">Movie year:</label>
			  <input type="text" id="newYear" required
			         [(ngModel)]="newYear" name="newYear"/>
			  <br>
              
              <p>  </p>
			  <label for="newGenre">Movie genre:</label>
			  <input type="text" id="newGenre" required
			         [(ngModel)]="newGenre" name="newGenre"/>
			  <br>
              
               <p>  </p>
			  <label for="newNotes">Movie notes:</label>
			  <input type="text" id="newNotes" required
			         [(ngModel)]="newNotes" name="newNotes"/>
			  <br>
			 
              <button type="button" (click)="doEdit();">Edit</button>
              <button type="button" (click)="doPrev()">Previous</button>
              <button type="button" (click)="doNext()">Next</button>
              <button type="button" (click)="showDialog();" [hidden]="!dialogDeleteButton">Delete</button>
            </form>
            <div id="deleteDialog" #dialogBox [hidden]="!dialogVar">
              <p>Do you really want to delete?
                <button (click)="doDeleteYes()">Yes</button>/
                <button (click)="doDeleteNo()">No</button>
              </p>
            </div>
            <p>{{message}}</p>
			 `
})

export class BrowseComponent implements OnInit {
    currentIndex: number = 1;
	data:Movie[];
    
    dialogVar = false;
    dialogDeleteButton = true;
    
    
    newName:string;
    newDirector: string;
    newYear: number;
    newGenre: string;
    newNotes?: string;
    message: string;

      /**
  * Injecting movie data from MovieService
  */
  ngOnInit(): void {
  }
    
    
    constructor(movieService: MovieService) {
    this.data = movieService.getMovies();
    if (this.data.length == 0) {
      this.message = "Already at the first of data.";
    } 
    else{
      this.currentIndex = 1;
      let thisMovie = this.data[0];
      this.newName = thisMovie.name;
      this.newDirector = thisMovie.director;
      this.newYear = thisMovie.year;
      this.newGenre = thisMovie.genre;
      this.newNotes = thisMovie.notes;
    }
    
    
  }
  
  
  /**
  * Loading previous data 
  */
  
   doPrev() {
    if (this.currentIndex <= 1) {
      this.message = "Already at the first of data.";
    } else {
      this.message = "";
      this.currentIndex--;
      let prevMovie = this.data[this.currentIndex-1];
      this.newName = prevMovie.name;
      this.newDirector = prevMovie.director;
      this.newYear = prevMovie.year;
      this.newGenre = prevMovie.genre;
      this.newNotes = prevMovie.notes;
    }
  }
  
  /**
  * Loading next data 
  */
  
   doNext() {
    if (this.currentIndex == this.data.length) {
      this.message = "Woops~ This is the last of data.";
    } else {
      this.message = "";
      this.currentIndex++;
      let nextMovie = this.data[this.currentIndex-1];
      this.newName = nextMovie.name;
      this.newDirector = nextMovie.director;
      this.newYear = nextMovie.year;
      this.newGenre = nextMovie.genre;
      this.newNotes = nextMovie.notes;
    }
  }
  
  
   /**
  * Edit data 
  */
  
   doEdit() {
    if (this.currentIndex <= 0) {
      this.message = "There is no unit to update";
    } 
    else if(this.data[this.currentIndex-1].name != this.newName){
      this.message = "Error";
    }
    else{
      this.data[this.currentIndex-1].name = this.newName;
      this.data[this.currentIndex-1].director = this.newDirector;
      this.data[this.currentIndex-1].year = this.newYear;
      this.data[this.currentIndex-1].genre = this.newGenre;
      this.data[this.currentIndex-1].notes = this.newNotes;
      this.message = this.data[this.currentIndex-1].name + " has been updated.";
    }
  }
 
  
    /**
   * Show the dialog for confirm a data is going to delete
   */
  showDialog() {
    this.dialogVar = true;
    this.dialogDeleteButton = false;
  }

   /**
   * Confirm to delete
   */
  doDeleteYes(){
    //delete the data by the current location in the array
    this.data.splice(this.currentIndex,1);
    //current location is going to decrease if the index same as the length of unit array
    if (this.currentIndex == this.data.length) {
      this.currentIndex--;
       //this.totalRecords--;
    }
    //show message if there is no unit  
    if (this.data.length == 0) {
      this.message = "No movies in the list."
      this.newName = "";
      this.newDirector = "";
    } 
    else { //The movie is in the list
      this.newName = this.data[this.currentIndex].name;
      this.newDirector = this.data[this.currentIndex].director;
      this.message = this.newName + " confirmed delete.";
      this.dialogVar = false;
      this.dialogDeleteButton = true;
    }
  }
  
  /**
   * Cancel to delete
   */
  doDeleteNo(){
    this.dialogVar = false;
    this.dialogDeleteButton = true;
  }

  
   /**
   * Load details into corresponding input field 
   * when data is selected from select list
   * @param value 
   */
  movieDetails(value: string): void {
  this.data.forEach(
    function(arrayMovie) {
        if (value == arrayMovie.name) {
          this.newName.value = arrayMovie.name;
          this.newDirector.value = arrayMovie.director;
          this.newYear.value = arrayMovie.year;
          this.newGenre.value = arrayMovie.genre;
          this.newNotes.value = this.data[this.currentIndex].notes;
        }
      }
    );
  }
  
  
  /**
   * Changing data by selecting a unit code
   * @param event 
   */
  onChange(event: Event) {
    this.newName = (<HTMLSelectElement>event.target).value;
  }
    
	
	
	
	
	
}