/**@author Pasindu Pushpika Sudasinghe Appuhamilage.
    Southern Cross University Melbourne.
    Version 4.2.0
**/
import { Component } from '@angular/core';
@Component({
  template: `
  <h2>Help</h2>
  <p>
  Go to different pages by click links.
  </p>`
  ,
  styleUrls: []
})
export class HelpComponent { }
