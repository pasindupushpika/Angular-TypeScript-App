/**@author Pasindu Pushpika Sudasinghe Appuhamilage.
    Southern Cross University Melbourne.
    Version 4.2.0
**/

import {Component } from '@angular/core';

@Component({
    template:`<p>This app is to save movie data with director, year and genre.</p>
			  <p>Use the above links to list, add or ....</p>
			 `
})

export class HomeComponent {

}