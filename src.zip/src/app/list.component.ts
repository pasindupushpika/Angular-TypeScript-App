/**@author Pasindu Pushpika Sudasinghe Appuhamilage.
    Southern Cross University Melbourne.
    Version 4.2.0
**/

import { Component } from '@angular/core';
import { MovieService, Movie } from './movie.service';

@Component({
    template:`<h2>Unit List</h2>
<table>
    <tr>
        <th>Movie name</th>
        <th>Director</th> 
        <th>Year</th> 
        <th>Genre</th> 
        <th>Notes</th> 
    </tr>
    <tr *ngFor="let movie of movies">
        <td>{{movie.name}}</td>
        <td>{{movie.director}}</td>
        <td>{{movie.year}}</td>
        <td>{{movie.genre}}</td>
        <td>{{movie.notes}}</td>
    </tr>
</table>
			 `
})

export class ListComponent {
	movies: Movie[];

    constructor(movieService: MovieService) {
    this.movies = movieService.getMovies();
  }

}


