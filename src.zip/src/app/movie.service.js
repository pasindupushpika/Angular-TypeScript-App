"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// 
// movie database injectable component
//
var core_1 = require("@angular/core");
;
/**
 * Injectable decorator dependency on components
 */
var MovieService = (function () {
    function MovieService() {
        this.movies = [
            // add data to Movie Array 
            { name: "movie1", director: "director1", year: 2020, genre: "Comedy", notes: "" },
            { name: "movie2", director: "director2", year: 2019, genre: "Horror", notes: "" },
            { name: "movie3", director: "director3", year: 2018, genre: "Action", notes: "" },
            { name: "movie4", director: "director4", year: 2017, genre: "Drama", notes: "" },
            { name: "movie5", director: "director5", year: 2016, genre: "Thriller", notes: "" },
            { name: "movie6", director: "director6", year: 2015, genre: "Romantic", notes: "" },
            { name: "movie7", director: "director7", year: 2014, genre: "Drama", notes: "" },
            { name: "movie8", director: "director8", year: 2013, genre: "Comedy", notes: "" },
            { name: "movie9", director: "director9", year: 2012, genre: "Thriller", notes: "" },
            { name: "movie10", director: "director10", year: 2011, genre: "Action", notes: "" }
        ];
    }
    /**
     * add movie
     * @param movie
     */
    MovieService.prototype.doAdd = function (movie) {
        this.movies[this.movies.length] = movie;
    };
    /**
* Check if a movie already exists
* @param addName
*/
    MovieService.prototype.isExist = function (addName) {
        for (var i = 0; i < this.movies.length; i++) {
            if (this.movies[i].name == addName) {
                return true;
            }
        }
        return false;
    };
    /**
     * Listing all movies in Movie array
     */
    MovieService.prototype.getMovies = function () {
        return this.movies;
    };
    /**
     * Get total records
      */
    MovieService.prototype.getTotalRecords = function () {
        return this.movies.length;
    };
    return MovieService;
}());
MovieService = __decorate([
    core_1.Injectable()
], MovieService);
exports.MovieService = MovieService;
//# sourceMappingURL=movie.service.js.map