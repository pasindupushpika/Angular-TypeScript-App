/**@author Pasindu Pushpika Sudasinghe Appuhamilage.
    Southern Cross University Melbourne.
    Version 4.2.0
**/
import { Injectable } from '@angular/core';

export interface Movie {name:string,director: string,year: number,genre: string,notes?: string,};

/**
 * Injectable decorator dependency on components
 */  
@Injectable()
export class MovieService{
    

    
	public movies: Movie[] = [
    
    // add data to Movie Array 
        
  { name:"movie1", director: "director1", year: 2020, genre: "Comedy", notes: ""},
  {name:"movie2", director: "director2", year: 2019, genre: "Horror", notes: ""},
  {name:"movie3", director: "director3", year: 2018, genre: "Action", notes: ""},
  {name:"movie4", director: "director4", year: 2017, genre: "Drama", notes: ""},
  {name:"movie5", director: "director5", year: 2016, genre: "Thriller", notes: ""},
  {name:"movie6", director: "director6", year: 2015, genre: "Romantic", notes: ""},
  {name:"movie7", director: "director7", year: 2014, genre: "Drama", notes: ""},
  {name:"movie8", director: "director8", year: 2013, genre: "Comedy", notes: ""},
   {name:"movie9", director: "director9", year: 2012, genre: "Thriller", notes: ""},
   {name:"movie10", director: "director10", year: 2011, genre: "Action", notes: ""}
	]; 
    
    
  	/**
	 * add movie
	 * @param movie 
	 */
	public doAdd ( movie : Movie){
		this.movies[this.movies.length]= movie;
	}
    
	
                 /**
	 * Check if a movie already exists
	 * @param addName
	 */
	public isExist (addName : string) : boolean {
		for (let i=0; i < this.movies.length ; i++){
			if (this.movies[i].name == addName){
				return true;
			}
		}
		return false;
	}

    
	/**
	 * Listing all movies in Movie array
	 */	
    
	public getMovies() : Movie[] {
		return this.movies;
	}
	 /**
	  * Get total records
	   */
	 public getTotalRecords(): number{
		return this.movies.length;
	}
  
}